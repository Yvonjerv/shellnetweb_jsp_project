create
    definer = root@localhost procedure up_getsystime()
BEGIN
	#Routine body goes here...
	SELECT CURRENT_TIMESTAMP;
END;

