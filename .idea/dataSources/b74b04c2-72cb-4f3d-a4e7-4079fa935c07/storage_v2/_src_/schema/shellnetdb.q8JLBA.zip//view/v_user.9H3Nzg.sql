create view v_user as
select `shellnetdb`.`t_user`.`utid`         AS `utid`,
       `shellnetdb`.`t_user`.`userid`       AS `userid`,
       `shellnetdb`.`t_user`.`username`     AS `username`,
       `shellnetdb`.`t_user`.`pwd`          AS `pwd`,
       `shellnetdb`.`t_user`.`mobile`       AS `mobile`,
       `shellnetdb`.`t_user`.`mail`         AS `mail`,
       `shellnetdb`.`t_user`.`companyname`  AS `companyname`,
       `shellnetdb`.`t_user`.`licencephoto` AS `licencephoto`,
       `shellnetdb`.`t_user`.`createtime`   AS `createtime`,
       `shellnetdb`.`t_usertype`.`utname`   AS `utname`
from (`shellnetdb`.`t_user`
         join `shellnetdb`.`t_usertype` on ((`shellnetdb`.`t_user`.`utid` = `shellnetdb`.`t_usertype`.`utid`)));

